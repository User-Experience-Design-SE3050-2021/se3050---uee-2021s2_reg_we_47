package com.example.boc_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class confirm_transfer_details extends AppCompatActivity {

    Button payNow,cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_transfer_details);

            Bundle bundle = getIntent().getExtras();

            String account = bundle.getString("ACCOUNT");
            String beneficName = bundle.getString("BENEFIC_NAME");
            String beneficAccount = bundle.getString("BENEFIC_ACC");
            String bank= bundle.getString("BANK");
            String branch = bundle.getString("BRANCH");
            String transAmount = bundle.getString("TRANS_AMOUNT");
            String transDate= bundle.getString("TRANS_DATE");
            String transDesc = bundle.getString("TRANS_DESC");

            TextView tv_account = findViewById(R.id.tv_account);
            TextView tv_beneficName = findViewById(R.id.tv_beneficiaryName);
            TextView tv_beneficAccount = findViewById(R.id.tv_beneficiaryAccount);
            TextView tv_bank= findViewById(R.id.tv_bank);
            TextView tv_branch = findViewById(R.id.tv_branch);
            TextView tv_transAmount = findViewById(R.id.tv_transferAmount);
            TextView tv_transDate = findViewById(R.id.tv_transDate);
            TextView tv_transDesc = findViewById(R.id.tv_transDesc);

            tv_account.setText(account);
            tv_beneficName.setText(beneficName);
            tv_beneficAccount.setText(beneficAccount);
            tv_bank.setText(bank);
            tv_branch .setText(branch);
            tv_transAmount.setText(transAmount);
            tv_transDate.setText(transDate);
            tv_transDesc.setText(transDesc);

            addListenerOnButtonPayNow();
            addListenerOnButtonCancel();

    }

    public void addListenerOnButtonPayNow(){
        payNow = findViewById(R.id.pay_now_transfer);

        payNow.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Toast.makeText(confirm_transfer_details.this, "Transaction processing..", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(confirm_transfer_details.this,ThirdPartyTransactions.class);
                startActivity(intent);
            }
        });

    }

    public void addListenerOnButtonCancel(){
        cancel = findViewById(R.id.cancel_transfer);

        cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Toast.makeText(confirm_transfer_details.this, "Transaction cancelled..", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(confirm_transfer_details.this,ThirdPartyTransactions.class);
                startActivity(intent);
            }
        });


    }
}
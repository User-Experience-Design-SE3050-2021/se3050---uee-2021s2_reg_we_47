package com.example.boc_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class DashboardActivity extends AppCompatActivity {

    private ImageView OwnAccTrans, contactus,bujetcal,account,billpayment,creditcard, transaction,thirdparty,profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

        //Own Account Transfer
        OwnAccTrans = (ImageView) findViewById(R.id.OwnaccTrans);
        account = findViewById(R.id.account);
        creditcard = findViewById(R.id.creditcard);
        contactus = findViewById(R.id.contactus);
        billpayment = findViewById(R.id.billpayment);
        transaction = findViewById(R.id.transaction);
        bujetcal = findViewById(R.id.cal);
        thirdparty = findViewById(R.id.thirdparty);

        profile = findViewById(R.id.profile);


        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ProfileActivity.class);
                startActivity(intent);
            }
        });
        thirdparty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ThirdPartyTransactions.class);
                startActivity(intent);
            }
        });
        bujetcal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),budget_calculator.class);
                startActivity(intent);
            }
        });
        billpayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),BillPaymentHomeActivity.class);
                startActivity(intent);
            }
        });
        OwnAccTrans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),OwnAccTransActivity.class);
                startActivity(intent);
            }
        });
        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),AccountsActivity.class);
                startActivity(intent);
            }
        });
        creditcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CreditCardPaymentsActivity.class);
                startActivity(intent);
            }
        });
        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ContactUsCallActivity.class);
                startActivity(intent);
            }
        });
        transaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TransactionHistoryActivity.class);
                startActivity(intent);
            }
        });

    }
}
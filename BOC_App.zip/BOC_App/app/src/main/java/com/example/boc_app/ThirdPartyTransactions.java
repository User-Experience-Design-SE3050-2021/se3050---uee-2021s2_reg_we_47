package com.example.boc_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class ThirdPartyTransactions extends AppCompatActivity {

    Button OneTimeTransfer,regBeneficiaries,manageBeneficiaries;
    ImageView home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_party_transactions);

        OneTimeTransfer = findViewById(R.id.oneTime);
        regBeneficiaries = findViewById(R.id.btn_regBenefic);
        manageBeneficiaries = findViewById(R.id.btn_manageBenefic);
        home = findViewById(R.id.home);

        OneTimeTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToOneTimeActivity();
            }
        });

        OneTimeTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),one_time_transfer.class);
                startActivity(intent);
            }
        });

        regBeneficiaries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToRegBeneficActivity();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),DashboardActivity.class);
                startActivity(intent);
            }
        });

    }

    private void  goToOneTimeActivity(){
        Intent intent = new Intent(this, one_time_transfer.class);
        startActivity(intent);
    }

    private void  goToRegBeneficActivity(){
        Intent intent = new Intent(this, registered_benefic_transfer.class);
        startActivity(intent);
    }


}